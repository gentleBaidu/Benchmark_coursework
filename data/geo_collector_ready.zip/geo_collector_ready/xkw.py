"""组卷网页面适配版。仅处理正常可访问的页面；不调用隐藏接口。"""
import argparse
import copy
import csv
import hashlib
import html as escape_html
import json
import re
import time
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from lxml import html, etree

BASE = Path(__file__).resolve().parent
START = 'https://zujuan.xkw.com/czdl/zsd22298/qt1801o2'
CARD = '.tk-quest-item.quesroot'
NEXT = 'a[data-type="nextPage"]'
DENIED_IMAGE_HASHES = {'f7e5f24de45dcdd7d97f2e73f413527312e7f49d37809ba02b3d2a2c25c0f286', '5c5b685fc5002925af58214e87c3c782baf4b20b4025dce927c94e3e2af888eb'}


def cls(name):
    return 'contains(concat(" ",normalize-space(@class)," ")," ' + name + ' ")'


def fragment(s):
    return html.fragment_fromstring(s or '<span></span>', create_parent='div')


def text(s):
    d = fragment(s)
    for br in d.xpath('.//br'):
        br.tail = '\n' + (br.tail or '')
    # retain cell and row boundaries when flattening data tables
    for n in d.xpath('.//td|.//th'):
        n.tail = '\t' + (n.tail or '')
    for n in d.xpath('.//tr|.//p'):
        n.tail = '\n' + (n.tail or '')
    return re.sub(r'[ \t\xa0]+', ' ', d.text_content()).strip()


def serial(n):
    return html.tostring(n, encoding='unicode', with_tail=False)


def inside(n):
    return escape_html.escape(n.text or '') + ''.join(html.tostring(c, encoding='unicode') for c in n)


def h(s):
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def image_refs(s, source, resource_dir=None):
    found = []
    for n in fragment(s).xpath('.//img'):
        src = n.get('data-src') or n.get('data-original') or n.get('src')
        if not src:
            continue
        remote = src.startswith(('https://', 'http://', '//', 'data:'))
        local_file = (Path(resource_dir) / Path(src).name) if resource_dir and not remote else None
        ref = {'url': urljoin(source, src) if remote or not resource_dir else None,
               'saved_reference': src, 'local_path': None,
               'source_local_path': str(local_file.resolve()) if local_file and local_file.exists() else None,
               'status': 'pending_download' if remote or not resource_dir else 'saved_resource_missing'}
        if ref not in found:
            found.append(ref)
    return found


def split_first(s):
    # Locate child question 1 in text tokens, never in HTML attributes.
    tokens = re.split(r'(<[^>]*>)', s)
    for i in range(0, len(tokens), 2):
        m = re.search(r'(?<!\d)1\s*[．、]', tokens[i])
        if m:
            return ''.join(tokens[:i]) + tokens[i][:m.start()], tokens[i][m.start():], ''.join(tokens[i+1:])
    raise ValueError('multi-question group: no first-child marker')


def answer_letters(answer_html, count):
    value = text(answer_html)
    # Only accept unambiguous visible answer forms; never scan explanations for letters.
    value = re.sub(r'^\s*[【\[]?答案[】\]]?\s*[:：]?\s*', '', value).strip()
    if count == 1 and re.fullmatch('[A-D]', value):
        return [value]
    numbered = re.findall(r'(?:^|[\s;；])(?:【\s*|\(\s*)?(\d+)(?:\s*】|\s*\)|[．.、:：])\s*([A-D])(?=$|[\s;；])', value)
    if len(numbered) == count and [int(x[0]) for x in numbered] == list(range(1, count+1)):
        return [x[1] for x in numbered]
    if re.fullmatch(r'[A-D](?:\s+[A-D])*', value) and len(value.split()) == count:
        return value.split()
    return [None] * count


def parse_card(raw, source, answer_html=None, resource_dir=None):
    card = html.fromstring(raw)
    content = card.xpath('.//*[' + cls('exam-item__cnt') + ']')
    if not content:
        raise ValueError('missing .exam-item__cnt')
    cnt = content[0]
    tables = cnt.xpath('.//table[@name="optionsTable"]')
    if not tables:
        raise ValueError('missing option tables')
    if any(t.getparent() is not cnt for t in tables):
        raise ValueError('nested option tables require parser adaptation')
    # The uploaded page stores each child as text followed by one options table.
    chunks, opts_html = [], []
    pending = escape_html.escape(cnt.text or '')
    for child in cnt:
        if child.tag == 'table' and child.get('name') == 'optionsTable':
            chunks.append(pending)
            opts_html.append(serial(child))
            pending = escape_html.escape(child.tail or '')
        else:
            pending += html.tostring(child, encoding='unicode')
    shared = ''
    if len(tables) > 1:
        before, first_text, rest = split_first(chunks[0])
        shared, chunks[0] = before, first_text + rest
    # Remove list numbering from shared material or a standalone question.
    if shared:
        shared = re.sub(r'^(\s*(?:<[^>]+>\s*)*)\d+\s*\.\s*', r'\1', shared, count=1)
    else:
        chunks[0] = re.sub(r'^(\s*(?:<[^>]+>\s*)*)\d+\s*\.\s*', r'\1', chunks[0], count=1)
    controls = card.xpath('.//a[@data-type="addToExam"]')
    meta = controls[0] if controls else card
    difficulty = meta.get('qdname')
    score = meta.get('qdvalue')
    if not difficulty:
        labels = card.xpath('.//*[' + cls('info-cnt') + ']')
        match = next((re.search(r'(容易|适中|困难)\s*\(([\d.]+)\)', n.text_content()) for n in labels if re.search(r'(容易|适中|困难)\s*\(([\d.]+)\)', n.text_content())), None)
        if match:
            difficulty, score = match.groups()
    knowledge, abilities = [], []
    for a in card.xpath('.//a[' + cls('knowledge-item') + ']'):
        label = a.text_content().strip()
        dest = a.get('href', '')
        if label:
            (abilities if re.search(r'/tre\d+-', dest) else knowledge).append(label)
    qid = card.get('questionid')
    detail = card.xpath('.//a[@data-btn-type="quesDetail"]/@href')
    if answer_html is None:
        # Saved page: keep only the uploaded answer DOM, no hidden endpoint lookup.
        ans = card.xpath('.//div[' + cls('answer') + ']')
        answer_html = ''.join(serial(n) for n in ans)
    answers = answer_letters(answer_html, len(tables))
    ans_imgs = image_refs(answer_html, source, resource_dir)
    rows = []
    for i, (stem, option_html) in enumerate(zip(chunks, opts_html), 1):
        options = {}
        for td in fragment(option_html).xpath('.//td'):
            label = re.match(r'^\s*([A-D])[．.、:：\s]', td.text_content())
            if label and label.group(1) not in options:
                options[label.group(1)] = {'text': td.text_content().strip(), 'html': inside(td),
                                         'images': image_refs(inside(td), source, resource_dir)}
        refs = image_refs(shared + stem + option_html, source, resource_dir)
        fingerprint = h(json.dumps([text(shared), text(stem), [(k, v['text']) for k, v in sorted(options.items())], [x['saved_reference'] for x in refs]], ensure_ascii=False))
        status = 'text_verified_format' if answers[i-1] else ('image_needs_transcription' if ans_imgs else 'missing_or_unrecognized')
        row = {'id': f'{qid or fingerprint[:16]}_{i}', 'group_id': qid or h(text(shared))[:20],
               'subquestion_index': i, 'group_child_count': len(tables), 'source_url': source,
               'detail_url': urljoin(source, detail[0]) if detail else None,
               'collected_at': datetime.now(timezone.utc).isoformat(), 'shared_stem_html': shared,
               'shared_stem_text': text(shared), 'stem_html': stem, 'stem_text': text(stem),
               'options': options, 'answer': answers[i-1], 'answer_status': status,
               'answer_raw_text': text(answer_html), 'answer_images': ans_imgs,
               'difficulty': difficulty, 'difficulty_value': float(score) if score else None,
               'metadata_scope': '网站题组标签；子题继承，未独立标注',
               'knowledge_points': list(dict.fromkeys(knowledge)), 'ability_tags': list(dict.fromkeys(abilities)),
               'media_type': '图文' if refs else '纯文本',
               'has_data_table': bool(fragment(shared + stem).xpath('.//table')),
               'images': refs, 'fingerprint': fingerprint,
               'question_html': shared + stem + option_html}
        row['quality_issues'] = issues(row)
        rows.append(row)
    declared = meta.get('childnum')
    if declared and int(declared) != len(rows):
        raise ValueError(f'child count mismatch: declared={declared}, parsed={len(rows)}')
    return rows


def issues(r):
    result = []
    if set(r['options']) != set('ABCD'):
        result.append('options_not_ABCD')
    if not r['stem_text'] and not r['images']:
        result.append('missing_stem')
    if r['answer'] not in list('ABCD'):
        result.append('answer_not_available_as_text')
    if not r['knowledge_points']:
        result.append('missing_knowledge_tags')
    if not r['difficulty']:
        result.append('missing_difficulty')
    if any(not im.get('local_path') for im in r['images']):
        result.append('question_images_not_local')
    return result


def export_record(row):
    """Keep downloaded answer images without retaining temporary authenticated URLs."""
    result = copy.deepcopy(row)
    for im in result.get('answer_images', []):
        im['url'] = None
        im['saved_reference'] = im.get('local_path') or '[temporary answer image URL omitted]'
        im.pop('source_local_path', None)
    return result


def save(out, rows, status):
    out.mkdir(parents=True, exist_ok=True)
    tmp = out / 'questions.jsonl.tmp'
    tmp.write_text(''.join(json.dumps(export_record(r), ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')
    tmp.replace(out / 'questions.jsonl')
    summary = {'actual_subquestions': len(rows), 'actual_groups': len(set(r['group_id'] for r in rows)),
               'target_subquestions': status.get('target', 1200), 'basic_complete': sum(not r['quality_issues'] for r in rows),
               'knowledge_points_subquestions_multilabel': dict(Counter(k for r in rows for k in r['knowledge_points']).most_common()),
               'knowledge_points_groups_multilabel': {},
               'difficulty_subquestions_inherited': dict(Counter(r['difficulty'] or '未知' for r in rows)),
               'media_type': dict(Counter(r['media_type'] for r in rows)),
               'answer_status': dict(Counter(r['answer_status'] for r in rows)),
               'correct_answer_distribution': dict(Counter(r['answer'] or '未知' for r in rows)),
               'option_count_distribution': dict(Counter(str(len(r['options'])) for r in rows)),
               'option_presence_counts': dict(Counter(k for r in rows for k in r['options'])),
               'data_table_subquestions': sum(r['has_data_table'] for r in rows),
               'unique_question_images': len(set(im['url'] or im['saved_reference'] for r in rows for im in r['images'])),
               'unique_answer_images': len(set(im['url'] or im['saved_reference'] for r in rows for im in r['answer_images'])),
               'quality_issues': dict(Counter(x for r in rows for x in r['quality_issues'])),
               'run_status': status,
               'notes': ['难度/知识点为题组原标签，子题继承；知识点与能力标签分开。', '纯文本指无img，含文字表格的题另行统计。', '答案缺失不猜测，图片答案不从URL推导；基础完整性不等于人工验收。']}
    groups = {r['group_id']: r for r in rows}
    summary['knowledge_points_groups_multilabel'] = dict(Counter(k for r in groups.values() for k in r['knowledge_points']).most_common())
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    with (out / 'questions.csv').open('w', encoding='utf-8-sig', newline='') as f:
        columns = ['id', 'group_id', 'shared_stem_text', 'stem_text', 'A', 'B', 'C', 'D', 'answer', 'answer_status', 'difficulty', 'difficulty_value', 'knowledge_points', 'ability_tags', 'media_type', 'has_data_table', 'detail_url', 'quality_issues']
        writer = csv.DictWriter(f, fieldnames=columns); writer.writeheader()
        for r in rows:
            d = {k: r.get(k, '') for k in columns}
            for k in 'ABCD': d[k] = r['options'].get(k, {}).get('text', '')
            for k in ['knowledge_points', 'ability_tags', 'quality_issues']: d[k] = '；'.join(r[k])
            writer.writerow({k: "'"+str(v) if str(v).startswith(('=', '+', '-', '@')) else v for k, v in d.items()})
    report = ['# 初中地理实际采集统计', '', f'实际解析 {len(rows)} 道小题，来自 {len(groups)} 组材料题。',
              f'通过基础完整性检查 {summary["basic_complete"]} 道；答案或图片不完整的记录不能直接用作离线评测。', '',
              '知识点和难度继承题组标签，并非重新逐题标注；知识点多标签总数可能超过题数。',
              '能力标签不计入地理知识点。图片答案不等于已经取得A/B/C/D标签。', '', str(status), '']
    for title, key in [('难度（小题继承）', 'difficulty_subquestions_inherited'), ('图文类型', 'media_type'), ('正确答案分布', 'correct_answer_distribution'), ('答案取得情况', 'answer_status'), ('选项数量', 'option_count_distribution'), ('知识点（题组数）', 'knowledge_points_groups_multilabel'), ('知识点（小题数）', 'knowledge_points_subquestions_multilabel')]:
        report += ['## '+title, '', '| 类别 | 数量 |', '|---|---:|'] + [f'| {k} | {v} |' for k, v in summary[key].items()] + ['']
    (out / 'summary.md').write_text('\n'.join(report), encoding='utf-8')
    # Self-contained local preview; unknown/missing image references are explicit.
    blocks = []
    for r in rows:
        q = fragment(r['question_html'])
        for n in q.xpath('.//script|.//iframe|.//object'): n.drop_tree()
        for n in q.iter():
            for key in list(n.attrib):
                if key.lower().startswith('on'): del n.attrib[key]
        mapping = {im['saved_reference']: im for im in r['images']}
        for n in q.xpath('.//img'):
            im = mapping.get(n.get('data-src') or n.get('data-original') or n.get('src'))
            if im and im.get('local_path'):
                n.set('src', im['local_path'])
            else:
                n.set('src', '')
                n.set('alt', '[图片未保存，请补齐原图]')
        blocks.append('<article><h3>'+escape_html.escape(r['id'])+'</h3>'+serial(q)+'<p>答案状态：'+r['answer_status']+'</p></article>')
    (out / 'preview.html').write_text('<!doctype html><meta charset="utf-8"><style>body{max-width:1000px;margin:30px auto;font:18px sans-serif}article{border-bottom:1px solid #aaa;padding:20px}td{padding:6px}img{max-width:100%}</style><h1>实际解析题目预览</h1>'+''.join(blocks), encoding='utf-8')
    (out / 'run_status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')


def package(out):
    path = out.parent / (out.name+'_dataset.zip')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.rglob('*')):
            if f.is_file(): z.write(f, f.relative_to(out))
    print('数据包：', path)


def parse_file(path, out, assets_dir=None):
    raw = path.read_text(encoding='utf-8')
    m = re.search(r'saved from url=\(\d+\)(https?://[^\s<>]+)', raw[:600])
    source = m.group(1) if m else START
    doc = html.fromstring(raw)
    rows, errors = [], []
    resource_dir = Path(assets_dir).resolve() if assets_dir else path.parent / (path.stem+'_files')
    for card in doc.xpath('//*['+cls('tk-quest-item')+' and '+cls('quesroot')+']'):
        try: rows.extend(parse_card(serial(card), source, resource_dir=resource_dir))
        except Exception as e: errors.append({'group_id': card.get('questionid'), 'error': str(e)})
    out.mkdir(parents=True, exist_ok=True)
    for row in rows:
        for im in row['images']+row['answer_images']:
            source_file = im.pop('source_local_path', None)
            if source_file:
                data = Path(source_file).read_bytes()
                digest = hashlib.sha256(data).hexdigest()
                suffix = '.png' if data.startswith(b'\x89PNG') else '.jpg' if data.startswith(b'\xff\xd8') else '.gif' if data.startswith(b'GIF8') else '.img'
                rel = 'images/'+digest+suffix
                (out/'images').mkdir(exist_ok=True)
                (out/rel).write_bytes(data)
                im.update(local_path=rel,status='access_denied_image' if digest in DENIED_IMAGE_HASHES else 'copied_from_saved_page')
        if any(im['status']=='access_denied_image' for im in row['answer_images']):
            row['answer_status']='access_denied_image'
        row['quality_issues']=issues(row)
    if errors: (out.mkdir(parents=True, exist_ok=True), (out/'parse_errors.json').write_text(json.dumps(errors,ensure_ascii=False,indent=2),encoding='utf-8'))
    save(out, rows, {'mode': 'uploaded_html', 'source_pages': 1, 'parse_errors': len(errors), 'resource_folder_present': resource_dir.exists()})
    package(out)
    print(json.dumps({k:json.loads((out/'summary.json').read_text())[k] for k in ['actual_subquestions','actual_groups','media_type','answer_status','difficulty_subquestions_inherited']}, ensure_ascii=False))
    return rows


def live(args):
    from playwright.sync_api import sync_playwright
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    rows = [json.loads(s) for s in (out/'questions.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()] if (out/'questions.jsonl').exists() else []
    ids = {r['id'] for r in rows}; fingerprints = {r['fingerprint'] for r in rows}
    checkpoint = json.loads((out/'checkpoint.json').read_text()) if (out/'checkpoint.json').exists() else {}
    image_cache = {im['url']: im for r in rows for im in r['images']+r['answer_images'] if im.get('url') and im.get('local_path') and (out/im['local_path']).exists()}
    def remember():
        (out/'checkpoint.json').write_text(json.dumps({'url':page.url},ensure_ascii=False),encoding='utf-8')
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(str(BASE/'local_profile'), headless=False, accept_downloads=False)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        reason = '结束'; pages = 0
        try:
            page.goto(checkpoint.get('url', START), wait_until='domcontentloaded', timeout=60000)
            print('请自行正常登录，确认是初中地理单选题列表。不要发送密码/Cookie。')
            input('题目正常显示后按回车开始；被拦截请按Ctrl+C结束：')
            def download(im):
                url = im.get('url')
                if not url or not url.startswith(('https://','http://')): return
                if url in image_cache:
                    im.update({k:v for k,v in image_cache[url].items() if k in ['local_path','status']}); return
                time.sleep(0.5)
                response = ctx.request.get(url, timeout=20000)
                if response.status in [401,403,405,429]: raise PermissionError('图片请求受限，已停止')
                ct = response.headers.get('content-type','').split(';')[0]
                if response.ok and ct.startswith('image/'):
                    data = response.body(); suffix = {'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp','image/gif':'.gif','image/svg+xml':'.svg'}.get(ct,'.img')
                    rel = 'images/'+hashlib.sha256(data).hexdigest()+suffix
                    (out/'images').mkdir(exist_ok=True); (out/rel).write_bytes(data)
                    im.update(local_path=rel,status='access_denied_image' if hashlib.sha256(data).hexdigest() in DENIED_IMAGE_HASHES else 'downloaded'); image_cache[url] = dict(im)
                else: im['status'] = 'not_image_or_http_error'
            while len(rows) < args.target and pages < args.max_pages:
                body = page.locator('body').inner_text()
                if re.search('您的访问被阻断|安全验证|滑动验证|请求过于频繁|Verify you are human|Access Denied',body,re.I):
                    reason='网站要求验证或拦截，停止采集'; break
                page.locator(CARD).first.wait_for(timeout=15000)
                before = page.locator(CARD).first.get_attribute('questionid')
                remember()
                cards = page.locator(CARD).all()
                for card in cards:
                    # User confirmed that clicking the question expands answers.
                    # No hidden endpoint, forced visibility or permission modification.
                    answer = card.locator('.item.answer')
                    if args.click_answers and not (answer.count() and answer.first.is_visible() and (answer.first.locator('img').count() or answer.first.inner_text().strip())):
                        card.locator('.exam-item__cnt').click(position={'x': 10, 'y': 10})
                        try:
                            page.wait_for_function('''qid => {
                                const card = [...document.querySelectorAll('.quesroot')].find(x=>x.getAttribute('questionid')===qid);
                                const a = card && card.querySelector('.item.answer');
                                return a && a.getClientRects().length && (a.innerText.trim() || [...a.querySelectorAll('img')].some(i=>i.complete&&i.naturalWidth>0));
                            }''',arg=card.get_attribute('questionid'),timeout=6000)
                        except Exception:
                            print('本题答案未正常展开；保留缺失标记。')
                    answer = card.locator('.item.answer')
                    visible_answer = answer.first.evaluate('(el)=>el.outerHTML') if answer.count() and answer.first.is_visible() else ''
                    raw = card.evaluate('(el)=>el.outerHTML')
                    parsed = parse_card(raw,page.url,answer_html=visible_answer)
                    for r in parsed:
                        if r['id'] in ids or r['fingerprint'] in fingerprints: continue
                        if args.images:
                            for im in r['images']+r['answer_images']:
                                try: download(im)
                                except PermissionError: raise
                                except Exception as e: im['status']='download_error_'+type(e).__name__
                        if any(im.get('status')=='access_denied_image' for im in r['answer_images']):
                            r['answer_status']='access_denied_image'
                        r['quality_issues']=issues(r)
                        rows.append(r); ids.add(r['id']); fingerprints.add(r['fingerprint'])
                        # Save every accepted subquestion. Summary/preview generated per page.
                        with (out/'questions.jsonl').open('a',encoding='utf-8') as f:
                            f.write(json.dumps(export_record(r),ensure_ascii=False)+'\n'); f.flush()
                        if len(rows)>=args.target: break
                    if len(rows)>=args.target: break
                pages += 1
                save(out,rows,{'mode':'local_browser','pages_this_run':pages,'actual':len(rows),'target':args.target})
                print(f'已采集{len(rows)}道小题；本次{pages}页')
                if len(rows)>=args.target: reason='达到目标小题数'; break
                nxt=page.locator(NEXT)
                if nxt.count()!=1 or not nxt.is_visible() or 'disabled' in (nxt.get_attribute('class') or ''):
                    reason='已到末页或下一页不可用'; break
                time.sleep(max(2,args.interval))
                nxt.click()
                page.wait_for_function('(old)=>{const el=document.querySelector(".tk-quest-item.quesroot");return el&&el.getAttribute("questionid")!==old}',arg=before,timeout=20000)
                remember()
            else: reason='达到目标或本次页数上限'
        except KeyboardInterrupt: reason='手动结束，已保留进度'
        except Exception as e: reason=type(e).__name__+': '+str(e)
        finally:
            ctx.close()
            save(out,rows,{'mode':'local_browser','reason':reason,'pages_this_run':pages,'actual':len(rows),'target':args.target})
            package(out); print(reason)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--html',type=Path,help='离线解析保存的列表网页，不访问网站')
    ap.add_argument('--out',default='result')
    ap.add_argument('--target',type=int,default=1200)
    ap.add_argument('--images',action='store_true',help='下载题目图片和正常显示的答案图片')
    ap.add_argument('--click-answers',action='store_true',help='正常点击题干并等待账号有权查看的答案展开')
    ap.add_argument('--assets-dir',type=Path,help='离线解析时显式指定保存网页的资源文件夹')
    ap.add_argument('--interval',type=float,default=3)
    ap.add_argument('--max-pages',type=int,default=120)
    a=ap.parse_args()
    if a.target<1 or a.max_pages<1: ap.error('target和max-pages必须大于0')
    if a.html: parse_file(a.html,Path(a.out).resolve(),a.assets_dir)
    else: live(a)


if __name__=='__main__': main()
