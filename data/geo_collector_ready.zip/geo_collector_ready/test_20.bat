@echo off
cd /d "%~dp0"
set "PLAYWRIGHT_BROWSERS_PATH=%~dp0browsers"
.venv\Scripts\python.exe xkw.py --target 20 --images --click-answers --out result
pause
