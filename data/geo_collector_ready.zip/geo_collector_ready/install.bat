@echo off
cd /d "%~dp0"
set "PLAYWRIGHT_BROWSERS_PATH=%~dp0browsers"
echo [1/3] Creating Python environment. This may take a few minutes...
python -m venv .venv
if errorlevel 1 goto error
echo [2/3] Installing Python packages...
.venv\Scripts\python.exe -m pip install --no-cache-dir -r requirements.txt
if errorlevel 1 goto error
echo [3/3] Installing Chromium browser...
.venv\Scripts\python.exe -m playwright install chromium
if errorlevel 1 goto error
echo Installation complete. Run test_20.bat or test_50.bat.
goto end
:error
echo Installation failed. Please send the error text shown above.
:end
pause
