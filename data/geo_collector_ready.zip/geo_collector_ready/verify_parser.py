"""Offline assertions against the actual uploaded-page extraction bundled here."""
import json
from pathlib import Path
rows=[json.loads(s) for s in (Path(__file__).parent/'sample_result/questions.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(rows)==23
assert len({r['group_id'] for r in rows})==10
assert all(set(r['options'])==set('ABCD') for r in rows)
assert sum(bool(r['shared_stem_text']) for r in rows)==22
assert sum(r['answer'] is not None for r in rows)==3
assert [r['answer'] for r in rows if r['group_id']=='35862587']==['B','D','A']
assert all((Path(__file__).parent/'sample_result'/im['local_path']).exists() for r in rows for im in r['images'])
assert sum(r['media_type']=='图文' for r in rows)==15
assert sum(r['answer_status']=='access_denied_image' for r in rows)==20
assert not any('能力' in k for r in rows for k in r['knowledge_points'])
print('PASS: actual uploaded page, 10 groups / 23 subquestions; options, shared stems, media, missing answers and tags checked.')
