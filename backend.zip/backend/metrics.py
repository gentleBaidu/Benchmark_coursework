# -*- coding: utf-8 -*-
"""指标统计：总正确率 + 分难度/知识点正确率 + 无效输出与接口错误。"""
from collections import defaultdict


def _rate(ok, total):
    return f"{ok / total * 100:.1f}%" if total else "-"


def summarize(results: list) -> dict:
    total = len(results)
    correct = sum(1 for r in results if r["is_correct"] is True)
    invalid = sum(1 for r in results if r["error_type"] in ("empty", "invalid_format"))
    api_error = sum(1 for r in results if r["error_type"] == "api_error")
    scored = total - invalid - api_error

    by_diff = defaultdict(lambda: [0, 0])
    by_kn = defaultdict(lambda: [0, 0])
    for r in results:
        if r["is_correct"] is None:
            continue
        d = r["difficulty"] or "未标注"
        by_diff[d][1] += 1
        by_diff[d][0] += 1 if r["is_correct"] else 0
        for k in (r["knowledge"] or ["未标注"]):
            by_kn[k][1] += 1
            by_kn[k][0] += 1 if r["is_correct"] else 0

    return {
        "total": total,
        "scored": scored,
        "correct": correct,
        "accuracy": (correct / scored) if scored else 0.0,
        "invalid": invalid,
        "api_error": api_error,
        "avg_latency_ms": int(sum(r["latency_ms"] for r in results) / total) if total else 0,
        "tokens_in": sum(r["tokens_in"] for r in results),
        "tokens_out": sum(r["tokens_out"] for r in results),
        "by_difficulty": {k: {"correct": v[0], "total": v[1], "rate": _rate(v[0], v[1])}
                          for k, v in sorted(by_diff.items())},
        "by_knowledge": {k: {"correct": v[0], "total": v[1], "rate": _rate(v[0], v[1])}
                         for k, v in sorted(by_kn.items(), key=lambda x: -x[1][1])},
    }


def format_report(s: dict, model_name: str, top_knowledge: int = 8) -> str:
    lines = [
        "=" * 46,
        f"模型：{model_name}",
        f"题数：{s['total']}  有效计分：{s['scored']}  正确：{s['correct']}",
        f"正确率：{s['accuracy'] * 100:.1f}%",
        f"无效输出：{s['invalid']}  接口错误：{s['api_error']}",
        f"平均耗时：{s['avg_latency_ms']} ms  tokens：{s['tokens_in']} in / {s['tokens_out']} out",
        "-" * 46,
        "分难度：",
    ]
    if set(s["by_difficulty"]) <= {"未标注"}:
        lines.append("  （题库无难度字段）")
    for k, v in s["by_difficulty"].items():
        if k == "未标注":
            continue
        lines.append(f"  {k:<12} {v['correct']}/{v['total']}  {v['rate']}")
    lines.append("分知识点（Top {}）：".format(top_knowledge))
    if set(s["by_knowledge"]) <= {"未标注"}:
        lines.append("  （题库无知识点字段）")
    for k, v in list(s["by_knowledge"].items())[:top_knowledge]:
        if k == "未标注":
            continue
        lines.append(f"  {k[:20]:<22} {v['correct']}/{v['total']}  {v['rate']}")
    lines.append("=" * 46)
    return "\n".join(lines)
