# -*- coding: utf-8 -*-
"""任务调度：创建任务、后台执行、进度落盘、取消。"""
import os
import random
import secrets
import threading
from datetime import datetime, timedelta, timezone

from backend.db_repo import load_from_db
from backend.evaluator import run_eval
from backend.model_client import MockClient, OpenAICompatClient
from backend.models import SUBJECT_CN, to_subject_code

TZ = timezone(timedelta(hours=8))


def now() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def list_models() -> list:
    """模型清单：mock 始终可用；配置了 MODEL_BASE_URL 后多一个本地/远程模型。"""
    models = [{"id": "mock", "name": "Mock（联调用）", "provider": "local", "enabled": True}]
    base = os.environ.get("MODEL_BASE_URL", "").strip()
    name = os.environ.get("MODEL_NAME", "").strip()
    if base and name:
        models.append({
            "id": "local",
            "name": f"{name}（{'本地' if 'localhost' in base or '127.0.0.1' in base else '远程'}）",
            "provider": "vllm" if "localhost" in base or "127.0.0.1" in base else "openai",
            "enabled": True,
        })
    return models


def build_client(model_id: str, temperature: float = 0.0):
    if model_id == "mock":
        return MockClient()
    if model_id == "local":
        base = os.environ.get("MODEL_BASE_URL", "").strip()
        name = os.environ.get("MODEL_NAME", "").strip()
        if not base or not name:
            raise ValueError("未配置 MODEL_BASE_URL / MODEL_NAME")
        return OpenAICompatClient(base, name,
                                  api_key=os.environ.get("MODEL_API_KEY", "EMPTY"),
                                  temperature=temperature)
    raise KeyError(model_id)


class RunBusy(Exception):
    pass


class RunManager:
    def __init__(self, store):
        self.store = store
        self._lock = threading.Lock()
        self._running_id = None
        self._cancel = threading.Event()

    # ---------- 创建 ----------
    def create(self, model_id: str, subject: str, sample_size: int,
               temperature: float = 0.0, concurrency: int = 4,
               difficulty: str = "") -> dict:
        with self._lock:
            if self._running_id:
                raise RunBusy("已有任务在运行，请等待结束或先取消")

        if difficulty:
            raise ValueError("题库暂无难度字段，暂不支持按难度筛选")

        concurrency = max(1, min(int(concurrency or 4), 16))

        build_client(model_id, temperature)  # 校验模型可用（mock/local）

        code = to_subject_code(subject)
        if code not in SUBJECT_CN:
            raise ValueError(f"未知学科：{subject}")
        questions = load_from_db(subject=code, limit=0, skip_images=True)
        if not questions:
            raise ValueError("该学科没有可用题目")
        if sample_size <= 0:
            raise ValueError("sample_size 必须大于 0")
        if sample_size > len(questions):
            raise ValueError(f"题量超过可用题数（最多 {len(questions)}）")

        picked = random.sample(questions, sample_size)
        run_id = "r_" + datetime.now(TZ).strftime("%Y%m%d_%H%M%S") + "_" + secrets.token_hex(2)
        run = {
            "run_id": run_id,
            "model_id": model_id,
            "model_name": next((m["name"] for m in list_models() if m["id"] == model_id), model_id),
            "subject": SUBJECT_CN[code],
            "subject_code": code,
            "difficulty": difficulty,
            "prompt_version": "v1",
            "sample_size": sample_size,
            "total": sample_size,
            "status": "pending",
            "done": 0, "correct": 0, "invalid": 0, "api_error": 0,
            "accuracy": None, "avg_latency_ms": None,
            "tokens_in": 0, "tokens_out": 0,
            "error_msg": "",
            "created_at": now(), "started_at": None, "finished_at": None,
            "_question_ids": [q.id for q in picked],
        }
        self.store.create_run(run)
        with self._lock:
            self._running_id = run_id
            self._cancel.clear()

        threading.Thread(target=self._execute,
                         args=(run_id, picked, model_id, temperature, concurrency),
                         daemon=True).start()
        return {"run_id": run_id, "status": "pending",
                "total": sample_size, "created_at": run["created_at"]}

    # ---------- 执行 ----------
    def _execute(self, run_id, questions, model_id, temperature, concurrency):
        try:
            self.store.update_run(run_id, status="running", started_at=now())
            client = build_client(model_id, temperature)

            def progress(done, total, r):
                self.store.add_item(run_id, r)

            run_eval(client, questions, concurrency=concurrency,
                     progress=progress, should_stop=self._cancel.is_set)

            status = "cancelled" if self._cancel.is_set() else "succeeded"
            self.store.update_run(run_id, status=status, finished_at=now())
        except Exception as e:
            self.store.update_run(run_id, status="failed", error_msg=str(e)[:500],
                                  finished_at=now())
        finally:
            with self._lock:
                self._running_id = None
            self._cancel.clear()

    # ---------- 取消 ----------
    def cancel(self, run_id: str) -> str:
        run = self.store.get_run(run_id)
        if not run:
            raise KeyError(run_id)
        if run["status"] not in ("pending", "running"):
            raise ValueError("任务已结束，无法取消")
        self._cancel.set()
        self.store.update_run(run_id, status="cancelled", finished_at=now())
        return "cancelled"

    # ---------- 查询 ----------
    def report(self, run_id: str) -> dict:
        run = self.store.get_run(run_id)
        if not run:
            raise KeyError(run_id)
        items = self.store.get_items(run_id)
        scored = sum(1 for r in items if r["is_correct"] is not None)
        correct = sum(1 for r in items if r["is_correct"] is True)

        def group(field):
            acc = {}
            for r in items:
                if r["is_correct"] is None:
                    continue
                vals = r.get(field) or []
                if field == "difficulty":
                    vals = [vals] if vals else []
                for v in vals:
                    if not v:
                        continue
                    a = acc.setdefault(v, [0, 0])
                    a[1] += 1
                    a[0] += 1 if r["is_correct"] else 0
            return [{"name": k, "correct": v[0], "total": v[1],
                     "rate": round(v[0] / v[1], 4) if v[1] else None}
                    for k, v in sorted(acc.items(), key=lambda x: -x[1][1])]

        return {
            "run_id": run_id,
            "is_final": run["status"] in ("succeeded", "failed", "cancelled"),
            "overall": {
                "total": run.get("total", run.get("done", 0)),
                "scored": scored,
                "correct": correct,
                "accuracy": round(correct / scored, 4) if scored else None,
                "invalid": run.get("invalid", 0),
                "api_error": run.get("api_error", 0),
                "tokens_in": run.get("tokens_in", 0),
                "tokens_out": run.get("tokens_out", 0),
                "avg_latency_ms": run.get("avg_latency_ms"),
            },
            "by_difficulty": group("difficulty"),
            "by_knowledge": group("knowledge"),
        }

    def items(self, run_id: str, page: int = 1, size: int = 20, only_wrong: bool = False):
        all_items = self.store.get_items(run_id)
        if only_wrong:
            all_items = [r for r in all_items if r["is_correct"] is False]
        total = len(all_items)
        start = max(page - 1, 0) * size
        rows = []
        for r in all_items[start:start + size]:
            rows.append({
                "question_id": r["question_id"],
                "stem": r.get("stem", ""),
                "options": r.get("options", {}),
                "images": r.get("images", []),
                "gold": r.get("gold", ""),
                "pred": r.get("pred", ""),
                "is_correct": r.get("is_correct"),
                "error_type": r.get("error_type", ""),
                "raw_output": r.get("raw_output", ""),
                "knowledge": r.get("knowledge", []),
                "difficulty": r.get("difficulty", ""),
                "latency_ms": r.get("latency_ms", 0),
                "tokens_in": r.get("tokens_in", 0),
                "tokens_out": r.get("tokens_out", 0),
            })
        return {"total": total, "page": page, "size": size, "items": rows}
