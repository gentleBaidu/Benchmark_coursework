# -*- coding: utf-8 -*-
"""数据源适配层：现在从 jsonl 读，等数据库就绪后只需再加一个 db_repo.py。"""
import json

from backend.models import Question


def load_jsonl(path: str, subject: str = None, only_choice: bool = True,
               only_answerable: bool = True, skip_images: bool = True,
               limit: int = 0) -> list:
    qs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                q = Question.from_record(json.loads(line))
            except Exception:
                continue
            if subject and q.subject != subject:
                continue
            if only_choice and q.qtype != "单选题":
                continue
            if only_answerable and not q.is_answerable:
                continue
            if skip_images and q.images:
                continue
            qs.append(q)
            if limit and len(qs) >= limit:
                break
    return qs
