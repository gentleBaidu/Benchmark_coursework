# -*- coding: utf-8 -*-
"""任务与逐题结果的本地存储。

为什么先用本地：数据库的 eval_runs 目前没有 UPDATE 权限、models 也不能写，
任务进度无法入库。这里用「一个任务一个 JSON 文件」先跑通完整流程，
等权限补齐后可加一个 DbRunStore，接口层不用改。
"""
import json
import os
import threading

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
RUNS_DIR = os.path.join(_ROOT, "数据", "任务")


class LocalRunStore:
    def __init__(self, directory: str = RUNS_DIR):
        self.dir = directory
        os.makedirs(self.dir, exist_ok=True)
        self._lock = threading.RLock()

    # ---------- 内部读写 ----------
    def _path(self, run_id: str) -> str:
        return os.path.join(self.dir, f"{run_id}.json")

    def _load(self, run_id: str):
        path = self._path(run_id)
        if not os.path.exists(path):
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    def _save(self, obj: dict):
        run_id = obj["run"]["run_id"]
        path = self._path(run_id)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)   # 原子替换，轮询时不会读到半个文件

    # ---------- 任务 ----------
    def create_run(self, run: dict):
        with self._lock:
            self._save({"run": run, "items": []})

    def get_run(self, run_id: str):
        with self._lock:
            obj = self._load(run_id)
            return dict(obj["run"]) if obj else None

    def update_run(self, run_id: str, **fields):
        with self._lock:
            obj = self._load(run_id)
            if not obj:
                return
            obj["run"].update(fields)
            self._save(obj)

    def add_item(self, run_id: str, item: dict):
        """写入一题结果，同时累加任务计数器。"""
        with self._lock:
            obj = self._load(run_id)
            if not obj:
                return
            run = obj["run"]
            obj["items"].append(item)

            run["done"] = run.get("done", 0) + 1
            if item.get("is_correct") is True:
                run["correct"] = run.get("correct", 0) + 1
            et = item.get("error_type") or ""
            if et in ("empty", "invalid_format"):
                run["invalid"] = run.get("invalid", 0) + 1
            elif et == "api_error":
                run["api_error"] = run.get("api_error", 0) + 1

            scored = run["done"] - run.get("invalid", 0) - run.get("api_error", 0)
            run["accuracy"] = (run["correct"] / scored) if scored > 0 else None
            run["_latency_sum"] = run.get("_latency_sum", 0) + int(item.get("latency_ms") or 0)
            run["_scored"] = scored
            run["avg_latency_ms"] = int(run["_latency_sum"] / run["done"]) if run["done"] else None
            run["tokens_in"] = run.get("tokens_in", 0) + int(item.get("tokens_in") or 0)
            run["tokens_out"] = run.get("tokens_out", 0) + int(item.get("tokens_out") or 0)
            self._save(obj)

    def get_items(self, run_id: str) -> list:
        with self._lock:
            obj = self._load(run_id)
            return list(obj["items"]) if obj else []

    def list_runs(self, page: int = 1, size: int = 10, status: str = ""):
        with self._lock:
            runs = []
            for name in os.listdir(self.dir):
                if not name.endswith(".json"):
                    continue
                obj = self._load(name[:-5])
                if obj:
                    runs.append(obj["run"])
            if status:
                runs = [r for r in runs if r.get("status") == status]
            runs.sort(key=lambda r: r.get("created_at", ""), reverse=True)
            total = len(runs)
            start = max(page - 1, 0) * size
            return total, [public_run(r) for r in runs[start:start + size]]

    def has_running(self) -> bool:
        with self._lock:
            for name in os.listdir(self.dir):
                if not name.endswith(".json"):
                    continue
                obj = self._load(name[:-5])
                if obj and obj["run"].get("status") in ("pending", "running"):
                    return True
            return False


def public_run(run: dict) -> dict:
    """去掉内部字段（下划线开头）、补齐前端字段。"""
    r = {k: v for k, v in run.items() if not k.startswith("_")}
    r["total"] = run.get("total", run.get("sample_size", 0))
    r["done"] = run.get("done", 0)
    r["invalid"] = run.get("invalid", 0)
    r["api_error"] = run.get("api_error", 0)
    r["accuracy"] = run.get("accuracy")
    r["tokens_in"] = run.get("tokens_in", 0)
    r["tokens_out"] = run.get("tokens_out", 0)
    r["error_msg"] = run.get("error_msg", "")
    return r
