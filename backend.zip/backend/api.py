# -*- coding: utf-8 -*-
"""FastAPI 接口层，接口契约见 后端核心/接口说明_给前端.md。"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.db_repo import subject_stats
from backend.runner import RunBusy, RunManager, list_models
from backend.store import LocalRunStore, public_run

app = FastAPI(title="初中政史地选择题评测后端", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # 单机演示：允许前端 dev server 跨域
    allow_methods=["*"],
    allow_headers=["*"],
)

store = LocalRunStore()
manager = RunManager(store)


class RunCreate(BaseModel):
    model_id: str
    subject: str
    difficulty: str = ""
    sample_size: int = Field(default=100, ge=1)
    temperature: float = 0.0


@app.get("/api/subjects")
def get_subjects():
    try:
        return {"subjects": subject_stats()}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"题库不可用：{e}")


@app.get("/api/models")
def get_models():
    return {"models": list_models()}


@app.post("/api/runs", status_code=202)
def create_run(body: RunCreate):
    try:
        return manager.create(body.model_id, body.subject, body.sample_size,
                              body.temperature, difficulty=body.difficulty)
    except RunBusy as e:
        raise HTTPException(status_code=409, detail=str(e))
    except KeyError as e:
        raise HTTPException(status_code=404, detail=f"模型不存在：{e}")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"创建任务失败：{e}")


@app.get("/api/runs")
def list_runs(page: int = 1, size: int = 10, status: str = ""):
    total, items = store.list_runs(page=max(page, 1), size=min(max(size, 1), 100), status=status)
    return {"total": total, "page": page, "size": size, "items": items}


@app.get("/api/runs/{run_id}")
def get_run(run_id: str):
    run = store.get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="任务不存在")
    return public_run(run)


@app.get("/api/runs/{run_id}/report")
def get_report(run_id: str):
    try:
        return manager.report(run_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="任务不存在")


@app.get("/api/runs/{run_id}/items")
def get_items(run_id: str, page: int = 1, size: int = 20, only_wrong: bool = False):
    if not store.get_run(run_id):
        raise HTTPException(status_code=404, detail="任务不存在")
    return manager.items(run_id, page=max(page, 1), size=min(max(size, 1), 100),
                         only_wrong=only_wrong)


@app.post("/api/runs/{run_id}/cancel")
def cancel_run(run_id: str):
    try:
        status = manager.cancel(run_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="任务不存在")
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e))
    return {"run_id": run_id, "status": status}
