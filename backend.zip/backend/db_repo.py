# -*- coding: utf-8 -*-
"""PostgreSQL 题目库读取（只读账号）。

连接参数从环境变量读取：
  BENCHMARK_DB_HOST       主机，如 10.147.171.236
  BENCHMARK_APP_PASSWORD  组员账号 benchmark_app 的密码
也可由调用方直接传入 host / password。

说明：该账号只读，且库里目前只有 public.questions；模型配置、任务、结果表尚未建立，
所以任务和逐题结果暂存本地（数据/评测结果/），等表建好再切换。
"""
import os
import sys

from backend.models import SUBJECT_CN, Question

# 若直接 import 本模块（不经 cli），也把项目自带的第三方库目录加进来
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
_PYLIBS = os.path.join(_ROOT, ".pylibs")
if os.path.isdir(_PYLIBS) and _PYLIBS not in sys.path:
    sys.path.insert(0, _PYLIBS)

DB_DEFAULTS = dict(port=5432, dbname="educational_llm_benchmark", user="benchmark_app")


def _connect(host=None, password=None):
    import psycopg
    from psycopg.rows import dict_row

    host = host or os.environ.get("BENCHMARK_DB_HOST", "")
    pwd = password or os.environ.get("BENCHMARK_APP_PASSWORD", "")
    if not host or not pwd:
        raise RuntimeError(
            "缺少数据库连接信息：请先设置环境变量 BENCHMARK_DB_HOST 与 BENCHMARK_APP_PASSWORD")
    conn = psycopg.connect(host=host, password=pwd, connect_timeout=5,
                           row_factory=dict_row, **DB_DEFAULTS)
    conn.execute("SET TRANSACTION READ ONLY")  # 账号本身只读，这里再加一道保险
    return conn


def load_from_db(subject=None, limit=0, only_choice=True, skip_images=True,
                 host=None, password=None) -> list:
    """按学科取题。subject 用库里的代码：history / politics / geography。

    - only_choice：只取单选（库里另有 6 道多选，当前评测只支持单选）
    - skip_images：默认跳过带图题（题库 52 道），避免纯文本模型看不到图还计分
    """
    sql = [
        "SELECT id, subject, question_type, stem, options, answer_keys,",
        "       cardinality(images) AS image_count",
        "FROM public.questions",
        "WHERE is_active = true",
        "  AND cardinality(answer_keys) >= 1",
    ]
    params = []
    if subject:
        sql.append("  AND subject = %s")
        params.append(subject)
    if only_choice:
        sql.append("  AND question_type = 'single_choice'")
    if skip_images:
        sql.append("  AND cardinality(images) = 0")
    sql.append("ORDER BY id")
    if limit:
        sql.append("LIMIT %s")
        params.append(limit)

    with _connect(host, password) as conn:
        rows = conn.execute("\n".join(sql), params).fetchall()

    return [q for q in (Question.from_db_row(r) for r in rows) if q.is_answerable]


# 前端展示顺序
SUBJECT_ORDER = ["history", "politics", "geography"]


def subject_stats(host=None, password=None) -> list:
    """各学科题量与可评测题量（单选 + 无图 + 有答案），供 /api/subjects 使用。"""
    sql = """
        SELECT subject,
               count(*) AS total,
               count(*) FILTER (
                   WHERE question_type = 'single_choice'
                     AND cardinality(images) = 0
                     AND cardinality(answer_keys) >= 1
               ) AS answerable
        FROM public.questions
        WHERE is_active
        GROUP BY subject
    """
    with _connect(host, password) as conn:
        rows = conn.execute(sql).fetchall()
    by_code = {r["subject"]: r for r in rows}
    out = []
    for code in SUBJECT_ORDER:
        r = by_code.get(code)
        out.append({
            "code": code,
            "name": SUBJECT_CN.get(code, code),
            "total": int(r["total"]) if r else 0,
            "answerable": int(r["answerable"]) if r else 0,
            "difficulties": [],  # 题库暂无难度字段
        })
    return out
