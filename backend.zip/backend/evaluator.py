# -*- coding: utf-8 -*-
"""评测引擎：组 prompt → 调模型 → 解析答案 → 判分。与数据库、具体模型无关。"""
import re
import time
from concurrent.futures import ThreadPoolExecutor


def build_prompt(q) -> str:
    """按题目实际选项生成 prompt（库里选项数 2~26 个，不能写死 A-D）。"""
    opts = "\n".join(f"{k}. {q.options[k]}" for k in sorted(q.options))
    return (f"题目：{q.stem}\n\n{opts}\n\n"
            f"请只回答正确选项的字母，不要解释。")


def parse_answer(text: str):
    """返回 (字母, 错误类型)。空输出/不是 A-Z 都记为无效，不当作答错。"""
    if not text or not text.strip():
        return "", "empty"
    t = text.strip()
    m = re.search(r"(?:答案|正确答案|选项|答)\s*[:：]?\s*[\(\[（]?\s*([A-Za-z])\s*[\)\]）]?", t)
    if m:
        return m.group(1).upper(), ""
    m = re.match(r"^\s*[\(\[（]?\s*([A-Za-z])\s*[\)\]）]?\s*[\.。、:：]", t)
    if m:
        return m.group(1).upper(), ""
    m = re.match(r"^\s*[\(\[（]?\s*([A-Za-z])\s*[\)\]）]?\s*$", t)
    if m:
        return m.group(1).upper(), ""
    m = re.search(r"[\(\[（]\s*([A-Z])\s*[\)\]）]", t)
    if m:
        return m.group(1), ""
    m = re.search(r"\b([A-Z])\b", t)
    if m:
        return m.group(1), ""
    return "", "invalid_format"


def evaluate_one(client, q) -> dict:
    prompt = build_prompt(q)
    t0 = time.perf_counter()
    raw, err_type, err_msg = "", "", ""
    tokens_in = tokens_out = 0
    try:
        out = client.complete(prompt, meta={"id": q.id, "answer": q.answer})
        raw = (out.get("text") or "").strip()
        tokens_in = out.get("tokens_in", 0)
        tokens_out = out.get("tokens_out", 0)
        pred, parse_err = parse_answer(raw)
        if parse_err:
            err_type = parse_err
    except Exception as e:  # 接口异常计入 api_error，不中断整批
        pred, err_type, err_msg = "", "api_error", str(e)[:200]
    latency_ms = int((time.perf_counter() - t0) * 1000)
    return {
        "question_id": q.id,
        "subject": q.subject,
        "qtype": q.qtype,
        "difficulty": q.difficulty,
        "knowledge": q.knowledge,
        "stem": q.stem,
        "options": q.options,
        "images": q.images,
        "gold": q.answer,
        "pred": pred,
        "is_correct": None if not pred else pred == q.answer,
        "error_type": err_type,
        "error_msg": err_msg,
        "raw_output": raw,
        "prompt": prompt,
        "latency_ms": latency_ms,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
    }


def run_eval(client, questions, concurrency: int = 1, progress=None, should_stop=None) -> list:
    """并发跑完所有题；progress(done, total, result) 报进度，should_stop() 支持取消。"""
    def stopped():
        return bool(should_stop and should_stop())

    results = []
    total = len(questions)
    if concurrency <= 1:
        for i, q in enumerate(questions, 1):
            if stopped():
                break
            r = evaluate_one(client, q)
            results.append(r)
            if progress:
                progress(i, total, r)
        return results

    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        for start in range(0, total, concurrency):
            if stopped():
                break
            batch = questions[start:start + concurrency]
            for r in pool.map(lambda q: evaluate_one(client, q), batch):
                if stopped():
                    break
                results.append(r)
                if progress:
                    progress(len(results), total, r)
    return results
