# -*- coding: utf-8 -*-
"""模型适配层：评测引擎只调用 complete()，换模型/换供应商不影响上层。

- MockClient：本地假模型，用于在真实 API 就绪前跑通闭环。
- OpenAICompatClient：任何 OpenAI 兼容接口（OpenAI、DeepSeek、vLLM、Ollama 等）。
"""
import json
import random
import time
import urllib.error
import urllib.request

SYSTEM_PROMPT = "你是一名初中老师，正在做选择题。你只需给出正确选项的字母，不解释。"


class MockClient:
    """按题目哈希确定性地“答对/答错”，默认 70% 正确，用来看指标是否正常。"""

    name = "mock"

    def __init__(self, accuracy: float = 0.7):
        self.accuracy = accuracy

    def complete(self, prompt: str, meta: dict = None) -> dict:
        meta = meta or {}
        gold = meta.get("answer") or "A"
        rnd = random.Random(f"{meta.get('id', '')}|{gold}")
        if rnd.random() < self.accuracy:
            letter = gold
        else:
            letter = rnd.choice([x for x in "ABCD" if x != gold])
        return {"text": f"答案：{letter}", "tokens_in": len(prompt), "tokens_out": 4}


class OpenAICompatClient:
    """POST {base_url}/chat/completions，兼容本地部署。"""

    def __init__(self, base_url: str, model: str, api_key: str = "EMPTY",
                 temperature: float = 0.0, timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.temperature = temperature
        self.timeout = timeout
        self.name = model

    def complete(self, prompt: str, meta: dict = None) -> dict:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": self.temperature,
            "max_tokens": 512,
        }
        req = urllib.request.Request(
            self.base_url + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self.api_key}"},
            method="POST",
        )
        # 网络错误 / 429 / 5xx 重试 2 次（共 3 次尝试）
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    data = json.loads(r.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", "ignore")[:200]
                if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise RuntimeError(f"HTTP {e.code}: {body}")
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise RuntimeError(f"网络错误：{e}")
        usage = data.get("usage") or {}
        return {
            "text": data["choices"][0]["message"]["content"],
            "tokens_in": usage.get("prompt_tokens", 0),
            "tokens_out": usage.get("completion_tokens", 0),
        }
