# -*- coding: utf-8 -*-
"""统一的题目数据模型：不同来源（jsonl/csv/数据库）先转成它，评测逻辑只认这个。"""
from dataclasses import dataclass, field

# 数据库里的学科代码 → 中文名（展示与统计统一用中文）
SUBJECT_CN = {"history": "历史", "politics": "政治", "geography": "地理"}
SUBJECT_CODE = {v: k for k, v in SUBJECT_CN.items()}
QTYPE_CN = {"single_choice": "单选题", "multiple_choice": "多选题"}


def to_subject_code(value: str) -> str:
    """中文名或代码都能转成库里的代码；不认识的原样返回。"""
    value = (value or "").strip()
    return SUBJECT_CODE.get(value, value)


@dataclass
class Question:
    id: str
    subject: str
    stem: str
    options: dict
    answer: str
    qtype: str = ""
    difficulty: str = ""
    grade: str = ""
    knowledge: list = field(default_factory=list)
    images: list = field(default_factory=list)
    source_url: str = ""
    subject_code: str = ""

    @classmethod
    def from_record(cls, rec: dict) -> "Question":
        return cls(
            id=str(rec.get("id", "")),
            subject=rec.get("subject", ""),
            stem=(rec.get("stem") or "").strip(),
            options={k.upper(): (v or "").strip() for k, v in (rec.get("options") or {}).items()},
            answer=(rec.get("answer") or "").strip().upper(),
            qtype=rec.get("qtype", ""),
            difficulty=rec.get("difficulty", ""),
            grade=rec.get("grade", ""),
            knowledge=list(rec.get("knowledge") or []),
            images=list(rec.get("images") or []),
            source_url=rec.get("detail_url", ""),
        )

    @classmethod
    def from_db_row(cls, row: dict) -> "Question":
        """PostgreSQL public.questions 的一行 → 统一模型。

        options 是 [{"label":"A","text":"..."}]，answer_keys 是 ["B"]；
        图片（bytea[]）按需另行读取，这里只记录有无。
        """
        code = row.get("subject", "")
        opts = {str(o["label"]).upper(): (o.get("text") or "").strip()
                for o in (row.get("options") or [])}
        keys = [str(k).upper() for k in (row.get("answer_keys") or [])]
        return cls(
            id=str(row.get("id", "")),
            subject=SUBJECT_CN.get(code, code),
            subject_code=code,
            stem=(row.get("stem") or "").strip(),
            options=opts,
            answer=keys[0] if keys else "",
            qtype=QTYPE_CN.get(row.get("question_type", ""), row.get("question_type", "")),
            images=["<db-image>"] * int(row.get("image_count") or 0),
        )

    @property
    def is_answerable(self) -> bool:
        """答案合法、至少两个选项且答案属于选项，才参与评测。"""
        return (self.answer in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                and len(self.options) >= 2
                and self.answer in self.options)
