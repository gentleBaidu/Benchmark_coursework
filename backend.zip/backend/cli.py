# -*- coding: utf-8 -*-
"""命令行入口：跑一次评测并输出报告。

示例：
  # 从 PostgreSQL 题库跑（需先设置 BENCHMARK_DB_HOST / BENCHMARK_APP_PASSWORD）
  python 后端核心/代码/backend/cli.py --limit 50 --subject 历史

  # 从本地 jsonl 跑（离线）
  python 后端核心/代码/backend/cli.py --source jsonl --limit 50

  # 接真实模型（OpenAI 兼容）
  python 后端核心/代码/backend/cli.py --limit 100 --model openai \
      --base-url http://localhost:8000/v1 --model-name qwen2.5-7b-instruct
"""
import argparse
import json
import os
import re
import sys
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 后端核心/代码/
ROOT = os.path.dirname(os.path.dirname(BASE_DIR))                       # 项目根目录
sys.path.insert(0, BASE_DIR)
# 项目自带的第三方库目录（psycopg 等装在这里，优先于系统包）
PYLIBS = os.path.join(ROOT, ".pylibs")
if os.path.isdir(PYLIBS):
    sys.path.insert(0, PYLIBS)

from backend.evaluator import run_eval                 # noqa: E402
from backend.metrics import summarize, format_report    # noqa: E402
from backend.model_client import MockClient, OpenAICompatClient  # noqa: E402
from backend.models import SUBJECT_CN                   # noqa: E402
from backend.repo import load_jsonl                     # noqa: E402

SUBJECT_MAP = {v: k for k, v in SUBJECT_CN.items()}     # 中文 -> 库里的代码

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def build_client(args):
    if args.model == "mock":
        return MockClient(accuracy=args.mock_accuracy)
    api_key = args.api_key or os.environ.get("OPENAI_API_KEY", "EMPTY")
    return OpenAICompatClient(args.base_url, args.model_name,
                              api_key=api_key, temperature=args.temperature)


def load_questions(args):
    """返回 (题目列表, 展示用的学科名)。"""
    subject = (args.subject or "").strip()
    if args.source == "db":
        from backend.db_repo import load_from_db
        code = SUBJECT_MAP.get(subject, subject)
        qs = load_from_db(subject=code, limit=args.limit, skip_images=not args.with_images,
                          host=args.db_host, password=args.db_password)
        return qs, SUBJECT_CN.get(code, code)
    # jsonl 里的 subject 是中文
    cn = SUBJECT_CN.get(subject, subject)
    qs = load_jsonl(args.data, subject=cn, limit=args.limit,
                    skip_images=not args.with_images)
    return qs, cn


def main():
    ap = argparse.ArgumentParser(description="初中选择题 LLM 评测")
    ap.add_argument("--source", choices=["db", "jsonl"], default="db")
    ap.add_argument("--data", default=os.path.join(ROOT, "数据", "history_21_answered.jsonl"),
                    help="source=jsonl 时的数据文件")
    ap.add_argument("--limit", type=int, default=50, help="题数，0=全部")
    ap.add_argument("--subject", default="历史", help="历史/政治/地理，或 history/politics/geography")
    ap.add_argument("--difficulty", default="", help="按难度子串过滤（仅 jsonl 数据有该字段）")
    ap.add_argument("--with-images", action="store_true", help="包含带图题（默认跳过）")
    ap.add_argument("--db-host", default="", help="覆盖环境变量 BENCHMARK_DB_HOST")
    ap.add_argument("--db-password", default="", help="覆盖环境变量 BENCHMARK_APP_PASSWORD")
    ap.add_argument("--model", choices=["mock", "openai"], default="mock")
    ap.add_argument("--mock-accuracy", type=float, default=0.7, help="mock 的模拟正确率")
    ap.add_argument("--base-url", default="https://api.openai.com/v1")
    ap.add_argument("--model-name", default="gpt-4o-mini")
    ap.add_argument("--api-key", default="")
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--concurrency", type=int, default=1)
    ap.add_argument("--out", default="", help="结果 jsonl 路径，默认放 数据/评测结果/")
    args = ap.parse_args()

    try:
        questions, subject_cn = load_questions(args)
    except Exception as e:
        print(f"[数据库] 读取失败：{e}")
        print("可先用离线数据：--source jsonl")
        return 2

    if args.difficulty:
        if args.source == "db":
            print("提示：数据库题目没有难度字段，--difficulty 已忽略")
        else:
            questions = [q for q in questions if args.difficulty in q.difficulty]
    if not questions:
        print("没有可用题目，检查 --source / --subject / --limit / --difficulty")
        return 1

    client = build_client(args)
    src = "PostgreSQL" if args.source == "db" else "jsonl"
    print(f"载入 {len(questions)} 题（{src} · {subject_cn} · 单选"
          f"{' · 不含图' if not args.with_images else ''}），模型：{client.name}")

    def progress(done, total, r):
        if done % 10 == 0 or done == total:
            flag = "对" if r["is_correct"] else ("空" if r["error_type"] else "错")
            print(f"  [{done}/{total}] {r['question_id']} -> {r['pred'] or '-'} ({flag})")

    t0 = time.time()
    results = run_eval(client, questions, concurrency=args.concurrency, progress=progress)
    summary = summarize(results)
    report = format_report(summary, client.name)
    print(report)
    print(f"总耗时：{time.time() - t0:.1f}s")

    safe_name = re.sub(r"[^\w.-]+", "_", client.name)
    stamp = time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time() * 1000) % 1000:03d}"
    out = args.out or os.path.join(ROOT, "数据", "评测结果", f"eval_{safe_name}_{stamp}.jsonl")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(out.replace(".jsonl", ".report.txt"), "w", encoding="utf-8") as f:
        f.write(report + "\n")
    print(f"逐题结果 -> {out}")


if __name__ == "__main__":
    sys.exit(main())
